package dev.stretchres.mixin;

public interface WindowAccess {
    void stretchres$reapply();
}
