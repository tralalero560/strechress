package dev.stretchres.mixin;

import com.mojang.blaze3d.platform.Window;
import dev.stretchres.StretchConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Подменяет размер фреймбуфера на виртуальный. Из-за этого размер GUI, камера,
 * главный рендер-таргет и мышь считаются в виртуальном разрешении, поэтому
 * растягивается всё, включая интерфейс.
 */
@Mixin(Window.class)
public abstract class WindowMixin implements WindowAccess {
    @Shadow private int framebufferWidth;
    @Shadow private int framebufferHeight;

    @Inject(method = "refreshFramebufferSize", at = @At("TAIL"), require = 0)
    private void stretchres$afterRefresh(CallbackInfo ci) {
        stretchres$reapply();
    }

    @Inject(method = "onFramebufferResize", at = @At("TAIL"), require = 0)
    private void stretchres$afterResize(long window, int w, int h, CallbackInfo ci) {
        stretchres$reapply();
    }

    @Override
    public void stretchres$reapply() {
        int[] real = StretchConfig.realSize();
        int[] v = StretchConfig.compute(real[0], real[1]);
        this.framebufferWidth = v[0];
        this.framebufferHeight = v[1];
    }
}
