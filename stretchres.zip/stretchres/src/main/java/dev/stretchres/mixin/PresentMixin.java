package dev.stretchres.mixin;

import com.mojang.blaze3d.opengl.GlTexture;
import dev.stretchres.StretchConfig;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Финальный вывод кадра: растягиваем виртуальное разрешение на всё окно. */
@Mixin(targets = "com.mojang.blaze3d.opengl.GlCommandEncoder")
public abstract class PresentMixin {
    private static int stretchres$fbo = 0;

    @Inject(method = "presentTexture", at = @At("HEAD"), cancellable = true, require = 0)
    private void stretchres$presentAny(Object view, CallbackInfo ci) {
        if (!StretchConfig.enabled) return;
        Minecraft mc = Minecraft.getInstance();
        int[] real = StretchConfig.realSize();
        int vw = mc.gameRenderer.mainRenderTarget().width;
        int vh = mc.gameRenderer.mainRenderTarget().height;
        if (vw == real[0] && vh == real[1]) return;

        int tex = ((GlTexture) mc.gameRenderer.mainRenderTarget().getColorTexture()).glId();
        if (stretchres$fbo == 0) stretchres$fbo = GL30.glGenFramebuffers();

        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, stretchres$fbo);
        GL30.glFramebufferTexture2D(GL30.GL_READ_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, tex, 0);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, 0);
        GL30.glBlitFramebuffer(0, 0, vw, vh, 0, 0, real[0], real[1],
                GL11.GL_COLOR_BUFFER_BIT, StretchConfig.linear ? GL11.GL_LINEAR : GL11.GL_NEAREST);
        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, 0);
        ci.cancel();
    }
}
