package dev.stretchres;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.lwjgl.glfw.GLFW;

public class StretchResClient implements ClientModInitializer {
    private static boolean wasDown = false;

    @Override
    public void onInitializeClient() {
        StretchConfig.load();
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            long win = GLFW.glfwGetCurrentContext();
            if (win == 0L) return;
            boolean down = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_F8) == GLFW.GLFW_PRESS;
            if (down && !wasDown && !(mc.gui.screen() instanceof StretchScreen)) {
                mc.gui.setScreen(new StretchScreen(mc.gui.screen()));
            }
            wasDown = down;
        });
    }
}
