package dev.stretchres;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class StretchScreen extends Screen {
    private final Screen parent;

    public StretchScreen(Screen parent) {
        super(Component.literal("StretchRes"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int x = this.width / 2 - 110;
        int y = this.height / 4;

        addRenderableWidget(Button.builder(Component.literal("Stretch: " + (StretchConfig.enabled ? "ON" : "OFF")), b -> {
            StretchConfig.enabled = !StretchConfig.enabled;
            StretchConfig.apply();
        }).bounds(x, y, 220, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Aspect: " + StretchConfig.ASPECT_NAMES[StretchConfig.aspectIndex]), b -> {
            StretchConfig.aspectIndex = (StretchConfig.aspectIndex + 1) % StretchConfig.ASPECT_NAMES.length;
            StretchConfig.apply();
        }).bounds(x, y + 26, 220, 20).build());

        int rh = StretchConfig.RES_HEIGHTS[StretchConfig.resIndex];
        addRenderableWidget(Button.builder(Component.literal("Resolution (height): " + (rh == 0 ? "Native" : rh + "p")), b -> {
            StretchConfig.resIndex = (StretchConfig.resIndex + 1) % StretchConfig.RES_HEIGHTS.length;
            StretchConfig.apply();
        }).bounds(x, y + 52, 220, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Scaling: " + (StretchConfig.linear ? "Smooth" : "Sharp pixels")), b -> {
            StretchConfig.linear = !StretchConfig.linear;
            StretchConfig.apply();
        }).bounds(x, y + 78, 220, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(x, y + 112, 220, 20).build());
    }

    @Override
    public void onClose() {
        StretchConfig.save();
        this.minecraft.setScreen(parent);
    }
}
