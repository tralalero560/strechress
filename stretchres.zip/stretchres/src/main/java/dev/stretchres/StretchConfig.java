package dev.stretchres;

import com.mojang.blaze3d.platform.Window;
import dev.stretchres.mixin.WindowAccess;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class StretchConfig {
    public static final String[] ASPECT_NAMES = {"Native", "4:3", "5:4", "16:10", "16:9", "21:9", "3:2", "1:1"};
    public static final double[] ASPECT_VALUES = {0, 4.0 / 3.0, 5.0 / 4.0, 16.0 / 10.0, 16.0 / 9.0, 21.0 / 9.0, 3.0 / 2.0, 1.0};
    public static final int[] RES_HEIGHTS = {0, 480, 600, 720, 768, 864, 900, 960, 1024, 1080, 1200, 1440, 2160};

    public static boolean enabled = true;
    public static int aspectIndex = 1;   // 4:3
    public static int resIndex = 0;      // native height
    public static boolean linear = false; // false = чёткие пиксели, true = сглаживание

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("stretchres.properties");
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        try (Reader r = Files.newBufferedReader(f)) {
            Properties p = new Properties();
            p.load(r);
            enabled = Boolean.parseBoolean(p.getProperty("enabled", "true"));
            aspectIndex = clamp(Integer.parseInt(p.getProperty("aspect", "1")), 0, ASPECT_NAMES.length - 1);
            resIndex = clamp(Integer.parseInt(p.getProperty("res", "0")), 0, RES_HEIGHTS.length - 1);
            linear = Boolean.parseBoolean(p.getProperty("linear", "false"));
        } catch (Exception ignored) {}
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("enabled", String.valueOf(enabled));
        p.setProperty("aspect", String.valueOf(aspectIndex));
        p.setProperty("res", String.valueOf(resIndex));
        p.setProperty("linear", String.valueOf(linear));
        try (Writer w = Files.newBufferedWriter(file())) {
            p.store(w, "StretchRes");
        } catch (IOException ignored) {}
    }

    private static int clamp(int v, int a, int b) { return Math.max(a, Math.min(b, v)); }

    /** Реальный размер фреймбуфера окна. */
    public static int[] realSize() {
        int[] w = new int[1], h = new int[1];
        GLFW.glfwGetFramebufferSize(GLFW.glfwGetCurrentContext(), w, h);
        return new int[]{Math.max(1, w[0]), Math.max(1, h[0])};
    }

    /** Виртуальное разрешение, в котором рендерится игра. */
    public static int[] compute(int realW, int realH) {
        if (!enabled) return new int[]{realW, realH};
        double aspect = ASPECT_VALUES[aspectIndex];
        if (aspect <= 0) aspect = (double) realW / realH;
        int h = RES_HEIGHTS[resIndex] == 0 ? realH : RES_HEIGHTS[resIndex];
        int w = (int) Math.round(h * aspect);
        return new int[]{Math.max(320, w), Math.max(240, h)};
    }

    /** Применить настройки «вживую». */
    public static void apply() {
        save();
        Minecraft mc = Minecraft.getInstance();
        Window window = mc.getWindow();
        ((WindowAccess) (Object) window).stretchres$reapply();
        stretchres$resize(mc);
    }

    private static void stretchres$resize(Minecraft mc) {
        Object[] targets = {mc, mc.gameRenderer};
        for (Object t : targets) {
            if (t == null) continue;
            try {
                java.lang.reflect.Method m = t.getClass().getMethod("resizeDisplay");
                m.invoke(t);
                return;
            } catch (Exception ignored) {}
        }
    }
}
